public class Main {
    public static void main(String[] args)  // parantez yok
        System.out.println("Hello")
    }
}
