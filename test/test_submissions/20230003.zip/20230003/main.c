#include <stdio.h>
int main(int argc, char *argv[]) {
    char *p = NULL;
    printf("%c\n", *p);   /* Segmentation fault */
    return 0;
}
