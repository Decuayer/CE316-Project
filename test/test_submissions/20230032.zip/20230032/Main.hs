main :: IO ()
main = putStrLn 42   -- Int, String bekleniyordu
