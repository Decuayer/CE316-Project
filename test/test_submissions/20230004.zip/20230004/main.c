#include <stdio.h>
int main(int argc char *argv[]) {  /* virgül eksik */
    printf("Hello\n")
    return 0
}
