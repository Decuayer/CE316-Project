import System.Environment (getArgs)
main :: IO ()
main = getArgs >>= mapM_ putStrLn
