import sys
x = int(sys.argv[1])   # argv[1] string "apple" → ValueError
print(x)
